<?php
include './inc/config.php';
include './inc/functions.php';
// Your PHP code here.

// Home Page template below.
?>

<?=template_header('Home', $project_path)?>

<div class="content">
	<h2>Home</h2>
	<p>Welcome to the home page!</p>
</div>

<?=template_footer()?>