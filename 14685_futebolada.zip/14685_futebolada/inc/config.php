<?php
// Number of records to show on each page
$records_per_page = 10;

// cinstantes.. variaveis
$project_path = "/14685_futebolada";
?>